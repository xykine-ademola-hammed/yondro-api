"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.modelMap = void 0;
const models_1 = require("../models");
exports.modelMap = {
    department: models_1.Department,
    organization: models_1.Organization,
    position: models_1.Position,
};
//# sourceMappingURL=type.js.map